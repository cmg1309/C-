 //7-3
//#include<stdio.h>
////#define rowzize 2
////#define colzize 3
//void input(int data[2][3], int rowzize, int colzize);
//int tot(int data[2][3], int rowzize, int colzize);
//void output(int data[2][3], int rowzize, int colzize);
//
//int main(void)
//{
//	int i, j, sum, rowzize, colzize;
//	int data[2][3];
//
//	rowzize = sizeof(data) / sizeof(data[0]);
//	colzize = sizeof(data[0]) / sizeof(data[0][0]);
//
//	input(data, rowzize, colzize);
//	sum = tot(data, rowzize, colzize);
//	printf("�� : %d, ��� : %lf\n", sum, sum / 6.0);
//	output(data, rowzize, colzize);
//	
//}
//void input(int data[2][3], int rowzize, int colzize)
//{
//	int i, j;
//
//	printf("6���� �����͸� �Է� : ");
//	for (i = 0; i < rowzize; i++)
//		for (j = 0; j < colzize; j++)
//			scanf_s("%d", &data[i][j]);
//}
//
//int tot(int data[2][3], int rowzize, int colzize)
//{
//	int i, j, sum = 0;
//
//	for (i = 0; i < rowzize; i++)
//	{
//		for (j = 0; j < colzize; j++)
//			sum += data[i][j];
//	}
//	return sum;
//}
//
//void output(int data[2][3], int rowzize, int colzize)
//{
//	int i, j;
//
//	for (i = 0; i < rowzize; i++)
//	{
//		for (j = 0; j < colzize; j++)
//		{
//			printf("%d ", data[i][j]);
//		}
//		puts(" ");
//	}
//}

// 7-5

#include<stdio.h>

#define rowzize 4
#define colzize 2

void input(int data[4][2]);
double output(int data[2][3], int sum, int midsum, int finalsum);

int main(void)
{
	int i, j, midsum = 0, finalsum = 0, sum = 0;
	double avg = 0;
	int data[rowzize][colzize] = { 0 };

	input(data);

	printf("       �߰�       �⸻       \n");
	printf("-----------------------------\n");
	for (i = 0; i < rowzize; i++)
	{
		for (j = 0; j < colzize; j++)
		{
			printf("%10d ", data[i][j]);
			sum = sum + data[i][j];
			if (j == 0) midsum = midsum + data[i][j];
			else finalsum = finalsum + data[i][j];
		}
		puts(" ");
	}
	output(data, sum, midsum, finalsum);
	puts(" ");
	return;
}
void input(int data[4][2])
{
	int i, j;
	printf("�߰� �⸻ ������ �Է��ϼ��� : ");
	for (i = 0; i < rowzize; i++)
	{
		for (j = 0; j < colzize; j++)
			scanf_s("%d", &data[i][j]);
	}
}

double output(int data[2][3], int sum, int midsum, int finalsum)
{
	printf("-----------------------------\n");
	printf("��� : %5.2f %10.2f\n", (double)midsum / rowzize, (double)finalsum / rowzize);
	printf("������ ������ %d�̰� ����� %.2lf�̴�.", sum, (double)sum / (rowzize * colzize));
}