#include<stdio.h>

void input(double data[]);				
double Avg(double* data, double sum);
void Score(double* sum);
void output(double sum, double* data);
void Graph(double sum, double* data);

int main(void)
{
	double data[3];						
	int select;							
	double sum = 0;

	while (1)							
	{
		printf("===== �޴� =====\n");
		printf("1. �����Է�\n");
		printf("2. �������\n");
		printf("3. ������ȸ\n");
		printf("4. ��� �׷���\n");
		printf("5. ���α׷� ����\n");

		printf("�޴� ���� : ");
		scanf_s("%d", &select);
		if (select == 1)
		{
			input(data);
		}
		else if (select == 2)
		{
			printf("������ ���Ǿ����ϴ�.\n");
		}
		else if (select == 3)
		{
			output(sum, data);
		}
		else if (select == 4)
		{
			sum = Avg(data, sum);
			printf("= ��� : %.2lf\n", sum);
			Graph(sum, data);
		}
		else if (select == 5)
		{
			printf("���α׷��� �����մϴ�.\n");
			break;
		}
	}
}

void input(double data[])				
{
	int i;
	printf("����, ����, ���� �����Է� : ");
	for (i = 0; i < 3; i++)
	{
		scanf_s("%lf", &data[i]);
	}
}

double Avg(double* data, double sum)		
{
	int i;
	for (i = 0; i < 3; i++)			
	{
		sum += data[i];
	}
	return sum / 3;					
}

void Score(double* sum)				
{
	if (*sum >= 90)
	{
		printf("A");
	}
	else if (*sum >= 80)
	{
		printf("B");
	}
	else if (*sum >= 70)
	{
		printf("C");
	}
	else if (*sum >= 60)
	{
		printf("D");
	}
	else
	{
		printf("F");
	}
}

void output(double sum, double *data)
{
	sum = Avg(data, sum);
	printf("\n===���===\n");
	printf("��� : %.2lf\n", sum);
	printf("���� : ");
	Score(&sum);
	printf("\n");
}

void Graph(double sum, double *data)
{
	int result = 0;
	result = sum / 10;

	switch (result)
	{
	case 9:
		printf("######### <9>\n");
		break;
	case 8:
		printf("######## <8>\n");
		break;
	case 7:
		printf("####### <7>\n");
		break;
	case 6:
		printf("###### <6>\n");
		break;
	case 5:
		printf("##### <5>\n");
		break;
	case 4:
		printf("#### <4>\n");
		break;
	case 3:
		printf("### <3>\n");
		break;
	case 2:
		printf("## <2>\n");
		break;
	case 1:
		printf("# <1>\n");
		break;
	case 0:
		printf(" <0>\n");
		break;
	}
}