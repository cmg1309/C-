#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>

int main(void)
{
	// 10-7
	//char* s1 = "java";
	//char* s2 = "java";

	//printf("strcmp(%s, %s) = %d\n", s1, s2, strcmp(s1, s2));
	//
	//s1 = "java";
	//s2 = "jav";
	//printf("strcmp(%s, %s) = %d\n", s1, s1, strcmp(s1, s2));

	//s1 = "jav";
	//s2 = "java";
	//printf("strcmp(%s, %s) = %d\n", s1, s1, strcmp(s1, s2));

	//printf("strcmp(%s, %s, %d) = %d\n", s1, s2, 3, strncmp(s1, s2, 3));


	// 10-8
	//char dest[80] = "Java";
	//char s[80] = "C is a language";

	//printf("%s\n", strcpy(dest, s));
	//printf("%d\n", strcpy_s(dest, 80, s));
	//printf("%s\n", dest);

	//printf("----------------\n");
	//printf("%s\n", strncpy(dest, "C#", 2));
	//printf("%d\n", strncpy_s(dest, 80, "C#", 2));
	//printf("%s\n", dest);

	//printf("----------------\n");
	//printf("%s\n", strncpy(dest, "C#", 3));
	//printf("%d\n", strncpy_s(dest, 80, "C#", 3));
	//printf("%s\n", dest);


	// 10-9
	//char dest[80] = "C";

	//printf("%s\n", dest);
	//printf("%s\n", strcat(dest, " is "));				// strcat ���� ���ڿ��� \0���� ����Ἥ �̾ ���
	//printf("%s\n", strcat(dest, "a proce ", 2));		// a���� 2��°���� "a "
	//printf("%s\n", strcat(dest, "procedural "));
	//printf("%s\n", strcat(dest, "language"));


	// 10-10
	//char str[] = "C and C++\t language are best!";
	//char* ptoken;
	//char* delimiter = " ,\t!";

	//printf("���ڿ� \"%s\"�� >>\n", str);
	//printf("������ [%s]�� �̿��Ͽ� ��ū�� ���� >>\n", delimiter);
	//ptoken = strtok(str, delimiter);
	//while (ptoken != NULL)
	//{
	//	printf("%s\n", ptoken);
	//	ptoken = strtok(NULL, delimiter);
	//}


	// 10-11
	//char str[] = "JAVA 2013 go c#";

	//printf("%d\n", strlen("java"));
	//printf("%s", strlwr(str));
	//printf("%s\n", strupr(str));

	//printf("%s ", strstr(str, "VA"));
	//printf("%s\n", strchr(str, 'A'));



	// 10-12
	//int i = 0;
	//char* pa[] = { "JAVA", "C#", "C++" };
	//char ca[][5] = { "JAVA", "C#", "C++" };

	//printf("%s ", pa[0]);
	//printf("%s ", pa[1]);
	//printf("%s\n", pa[2]);

	//printf("%s ", ca[0]);
	//printf("%s ", ca[1]);
	//printf("%s\n", ca[2]);

	//printf("%c %c %c\n", pa[0][1], pa[1][1], pa[2][1]);
	//printf("%c %c %c\n", pa[0][1], pa[1][1], pa[2][1]);



	// ���α׷� �ǽ� ����
	char data[80];
	int i = 0, line;

	printf("����ڸ� �Է��ϼ��� -> ");
	scanf_s("%s", data, 80);
	line = strlen(data);
	
	printf("������ �Է��� ���ڿ����� �빮�ڿ� �ҹ��ڸ� �ݴ�� ��ȯ�ϸ� -> \n");
	for (i = 0; i < line; i++)
	{
		if(isupper(data[i]))
			printf("%c", tolower(data[i]));
		else if (islower(data[i]))
			printf("%c", toupper(data[i]));
	}
}

// 10-13
//int main(int argc, char* argv[])
//{
//	int i = 0;
//
//	printf("���� ������ ����(command line arguments) >>\n");
//	printf("argc = %d\n", argc);
//	for (i = 0; i < argc; i++)
//		printf("argv[%d] = %s\n", i, argv[i]);
//}