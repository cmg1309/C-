#include<stdio.h>

int main(void)
{
	printf("BCPL, "); printf("B, ");
	puts("C"); printf("C++, ");
	printf("Java, "); puts("C#");

	return 0;
}