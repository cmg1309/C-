#include<stdio.h>

int main(void)
{
	printf("%d,%d,%d\n", 4, 014, 0xE);
	printf("%f,%f%f\n", 4.3, 4.14e2, 4.14E-1);

	return 0;
}